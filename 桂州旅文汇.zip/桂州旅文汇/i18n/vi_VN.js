// vi_VN.js（越南语）
const languageMap = {
    头像: 'Ảnh đại diện',
    用户名: 'Tên người dùng',
    请输入用户名: 'Vui lòng nhập tên người dùng',
    收货地址: 'Địa chỉ nhận hàng',
    请输入收货地址: 'Vui lòng nhập địa chỉ',
    收货人: 'Người nhận',
    请输入收货人: 'Vui lòng nhập tên người nhận',
    联系方式: 'Liên hệ',
    请输入联系方式: 'Vui lòng nhập số điện thoại',
    密码: 'Mật khẩu',
    语言: 'Ngôn ngữ',
    保存: 'Lưu',
    系统设置: 'Cài đặt hệ thống',
    联系客服: 'Liên hệ hỗ trợ',
    意见反馈: 'Phản hồi',
    关于我们: 'Về chúng tôi',
    退出登录: 'Đăng xuất',
    我的订单: 'Đơn hàng của tôi',
    全部订单: 'Tất cả đơn hàng',
    待付款: 'Chờ thanh toán',
    '待出行/发货': 'Chờ giao hàng',
    '退款/退货': 'Hoàn tiền/Trả hàng'
  };
  
  module.exports = { languageMap };