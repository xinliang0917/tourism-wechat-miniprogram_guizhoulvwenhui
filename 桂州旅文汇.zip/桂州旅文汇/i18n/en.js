const languageMap = {
  简体中文: 'Simplified Chinese',
  英文: 'English',
  我的订单: 'My Orders',
  地址管理: 'Address Management',
  关于我们: 'About Us',
  系统设置: 'System Settings',
  联系客服: 'Contact Support',
  意见反馈: 'Feedback',
  全部订单: 'All Orders',
  待付款: 'Pending Payment',
  待发货: 'Pending Delivery',
  待收货: 'Pending Receipt',
  已完成: 'Completed',
  '待出行/发货': 'Pending Delivery',
  '退款/退货': 'Refund or Return',
  取消订单: 'Cancel Order',
  订单详情: 'Order Details',
  订单号: 'Order Number',
  订单状态: 'Order Status',
  商品信息: 'Product Information',
  商品名称: 'Product Name',
  退出登录: 'Log Out'
}

module.exports = {
  languageMap: languageMap
}
