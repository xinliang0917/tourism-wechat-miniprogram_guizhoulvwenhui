Page({
  data: {
    cartList: [
      {
        id: 1,
        name: "丝巾",
        price: 48,
        quantity: 1,
        image: "/images/goods1.jpg",
        checked: false
      },
      {
        id: 2,
        name: "瓷杯",
        price: 68,
        quantity: 2,
        image: "/images/goods2.jpg",
        checked: false
      }
    ],
    totalPrice: 0,
    selectedCount: 0
  },
  onLoad: function(options) {
    // 从缓存中获取购物车数据
    const cartList = wx.getStorageSync('cart') || this.data.cartList;
    this.setData({ cartList }, () => {
      this.calculateTotal();
    });
    this.calculateTotal();
  },
  toggleCheck: function(e) {
    const index = e.currentTarget.dataset.index;
    const cartList = this.data.cartList;
    cartList[index].checked = !cartList[index].checked;
    this.setData({ cartList }, () => {
      wx.setStorageSync('cart', cartList);
      this.calculateTotal();
    });
    this.calculateTotal();
  },
  increaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const cartList = this.data.cartList;
    const item = cartList.find(item => item.id === id);
    if (item && item.quantity < 99) {
      item.quantity++;
      this.setData({ cartList }, () => {
        wx.setStorageSync('cart', cartList);
      this.calculateTotal();
    });
      this.calculateTotal();
    }
  },
  decreaseQuantity: function(e) {
    const id = e.currentTarget.dataset.id;
    const cartList = this.data.cartList;
    const item = cartList.find(item => item.id === id);
    if (item && item.quantity > 1) {
      item.quantity--;
      this.setData({ cartList }, () => {
        wx.setStorageSync('cart', cartList);
      this.calculateTotal();
    });
      this.calculateTotal();
    }
  },
  calculateTotal: function() {
    const cartList = this.data.cartList;
    let totalPrice = 0;
    let selectedCount = 0;
    cartList.forEach(item => {
      if (item.checked) {
        totalPrice += item.price * item.quantity;
        selectedCount++;
      }
    });
    this.setData({ totalPrice, selectedCount });
  },
  handleBuy: function() {
    // 处理购买逻辑
    wx.showToast({
      title: '购买成功',
      icon: 'success'
    });
  },
  deleteItem(e) {
    const index = e.currentTarget.dataset.index;
    wx.showModal({
      title: '提示',
      content: '确定要删除这个商品吗？',
      success: (res) => {
        if (res.confirm) {
          const cartList = this.data.cartList.filter((item, i) => i !== index);
          this.setData({ cartList }, () => {
      this.calculateTotal();
    });
          wx.setStorageSync('cart', cartList);
          this.calculateTotal();
          wx.showToast({
            title: '删除成功',
            icon: 'success'
          });
        }
      }
    });
  },
});