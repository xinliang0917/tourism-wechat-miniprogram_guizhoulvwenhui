// pages/order/order.js
Page({
  data: {
    loading: false,
    error: null,
    currentType: 'all',
    filteredOrders: [],
    orderList: [
      {
        id: 25041501,
        name: '非遗图案丝巾',
        status: '已完成',
        date: '2023-10-01',
        total: 48,
        quantity: 1, 
        image: '/images/goods1.jpg',
      },
      {
        id: 25041502,
        name: '瓷杯盲盒',
        status: '待发货',
        date: '2023-10-02',
        total: 132,
        quantity: 2, 
        image: '/images/goods2.jpg',
      }
    ]
  },

  onLoad() {
    this.loadOrders();
  },

  loadOrders() {
    this.setData({ loading: true, error: null });
    setTimeout(() => {
      this.setData({ 
        filteredOrders: this.data.orderList,
        loading: false 
      });
    }, 500);
  },

  handleError(msg) {
    this.setData({
      error: msg,
      loading: false
    });
    wx.showToast({
      title: msg,
      icon: 'none'
    });
  },

  switchType(e) {
    const type = e.currentTarget.dataset.type;
    this.setData({
      currentType: type
    });
    this.filterOrders(type);
  },

  filterOrders(type) {
    let filteredOrders;
    if (type === 'all') {
      // 显示全部订单
      filteredOrders = this.data.orderList;
    } else {
      // 定义选项卡类型与实际状态的映射关系
      const statusMap = {
        unpaid: '待付款',
        shipped: '待发货',
        received: '待收货',
        completed: '已完成'
      };
      filteredOrders = this.data.orderList.filter(order => 
        order.status === statusMap[type]
      );
    }
    this.setData({ 
      filteredOrders,
      activeType: type // 同步更新激活状态
    });
  }
})